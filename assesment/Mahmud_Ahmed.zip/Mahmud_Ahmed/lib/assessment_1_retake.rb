# Define your methods here.
require "byebug"

def string_map!(str, &prc)
  str.each_char.with_index do |char, idx|
    str[idx] = prc.call(char)
  end
  str
end

def three?(arr,&prc)
  count = arr.count { |ele| prc.call(ele)}
  count == 3
end

def nand_select(arr, prc1, prc2)
  arr.reject { |ele| prc1.call(ele) && prc2.call(ele) }
end

def hash_of_array_sum(hash)
  hash.values.flatten.sum
end

def abbreviate(sent)
  words = sent.split
  words.map! do |word|
    word.length > 4 ? word.delete("aeiouAEIOU") : word
  end
  words * " "
end

def hash_selector(hash,*nums)
  return hash if nums.empty?
  hash.select { |k,v| nums.include?(k) }
end

